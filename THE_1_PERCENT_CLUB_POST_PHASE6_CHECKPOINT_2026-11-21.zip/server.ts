import "dotenv/config";
import express from "express";
import type { Request, Response, NextFunction } from "express";
import path from "node:path";
import zlib from "node:zlib";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

function resolvePort(): number {
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i++) {
    if ((argv[i] === "--port" || argv[i] === "-p") && argv[i + 1]) {
      const parsed = parseInt(argv[i + 1], 10);
      if (!isNaN(parsed) && parsed > 0) return parsed;
    }
    if (argv[i].startsWith("--port=")) {
      const parsed = parseInt(argv[i].split("=")[1], 10);
      if (!isNaN(parsed) && parsed > 0) return parsed;
    }
  }
  if (process.env.PORT && process.env.PORT !== "8080") {
    const parsed = parseInt(process.env.PORT, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  return 3000;
}

function resolveHost(): string {
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i++) {
    if ((argv[i] === "--host" || argv[i] === "-h") && argv[i + 1]) {
      return argv[i + 1];
    }
    if (argv[i].startsWith("--host=")) {
      return argv[i].split("=")[1];
    }
  }
  return process.env.HOST || "0.0.0.0";
}

const port = resolvePort();
const host = resolveHost();

// Native zlib compression middleware
function gzipMiddleware(req: Request, res: Response, next: NextFunction) {
  const acceptEncoding = (req.headers["accept-encoding"] as string) || "";
  if (!acceptEncoding.includes("gzip")) {
    return next();
  }

  const originalSend = res.send.bind(res);
  (res as any).send = function (body: any): Response {
    if (res.headersSent) return originalSend(body);

    const contentType = (res.getHeader("content-type") as string) || "";
    const isCompressible =
      contentType.includes("text") ||
      contentType.includes("javascript") ||
      contentType.includes("css") ||
      contentType.includes("json") ||
      contentType.includes("svg");

    if (isCompressible) {
      const buffer = Buffer.isBuffer(body) ? body : Buffer.from(typeof body === "string" ? body : JSON.stringify(body));
      if (buffer.length > 512) {
        try {
          const gzipped = zlib.gzipSync(buffer);
          res.setHeader("Content-Encoding", "gzip");
          res.setHeader("Content-Length", gzipped.length);
          res.setHeader("Vary", "Accept-Encoding");
          return originalSend(gzipped);
        } catch {
          return originalSend(body);
        }
      }
    }
    return originalSend(body);
  };
  next();
}

app.use(gzipMiddleware);

// Serve static assets from root with ETag, Last-Modified, and optimized Cache-Control
app.use(
  express.static(path.join(__dirname, "."), {
    etag: true,
    lastModified: true,
    setHeaders: (res, filePath) => {
      res.setHeader("Vary", "Accept-Encoding");
      if (filePath.endsWith(".html") || filePath.endsWith(".css") || filePath.endsWith(".js")) {
        res.setHeader("Cache-Control", "no-cache, must-revalidate");
      } else if (
        filePath.endsWith(".svg") ||
        filePath.endsWith(".woff2") ||
        filePath.endsWith(".png") ||
        filePath.endsWith(".jpg") ||
        filePath.endsWith(".webp")
      ) {
        res.setHeader("Cache-Control", "public, max-age=86400, stale-while-revalidate=604800");
      }
    },
  })
);

// ==========================================================================
// REAL MARKET DATA ENDPOINT (SERVER-SIDE INTEGRATION)
// Securely proxies market-data requests to avoid exposing API keys in client.
// Implements server-side caching to respect provider rate limits and quotas.
// Never fabricates prices: marks status as UNAVAILABLE if credentials are unset.
// ==========================================================================

interface Instrument {
  id: string;
  cat: string;
  catAr: string;
  symbol: string;
  nameEn: string;
  nameAr: string;
  unit: string;
  currency: string;
  biquoteSymbol: string;
  instrumentType: string;
  instrumentTypeAr: string;
}

const REQUIRED_INSTRUMENTS: Instrument[] = [
  // 1. Precious Metals Spot Prices
  { id: "gold", cat: "METALS", catAr: "", symbol: "XAU/USD", nameEn: "Gold Spot", nameAr: "", unit: "oz", currency: "USD", biquoteSymbol: "XAUUSD", instrumentType: "SPOT", instrumentTypeAr: "" },
  { id: "silver", cat: "METALS", catAr: "", symbol: "XAG/USD", nameEn: "Silver Spot", nameAr: "", unit: "oz", currency: "USD", biquoteSymbol: "XAGUSD", instrumentType: "SPOT", instrumentTypeAr: "" },
  { id: "platinum", cat: "METALS", catAr: "", symbol: "XPT/USD", nameEn: "Platinum Spot", nameAr: "", unit: "oz", currency: "USD", biquoteSymbol: "XPTUSD", instrumentType: "SPOT", instrumentTypeAr: "" },
  { id: "palladium", cat: "METALS", catAr: "", symbol: "XPD/USD", nameEn: "Palladium Spot", nameAr: "", unit: "oz", currency: "USD", biquoteSymbol: "XPDUSD", instrumentType: "SPOT", instrumentTypeAr: "" },

  // 2. Commodities & Energy
  { id: "brent", cat: "ENERGY", catAr: "", symbol: "UKOIL", nameEn: "Brent Crude", nameAr: "", unit: "bbl", currency: "USD", biquoteSymbol: "UKOIL", instrumentType: "COMMODITY_CFD", instrumentTypeAr: "" },
  { id: "wti", cat: "ENERGY", catAr: "", symbol: "USOIL", nameEn: "WTI Crude", nameAr: "", unit: "bbl", currency: "USD", biquoteSymbol: "USOIL", instrumentType: "COMMODITY_CFD", instrumentTypeAr: "" },

  // 3. Major Stock Indices
  { id: "spx", cat: "INDICES", catAr: "", symbol: "US500", nameEn: "S&P 500", nameAr: "", unit: "pts", currency: "USD", biquoteSymbol: "US500", instrumentType: "INDEX_CFD", instrumentTypeAr: "" },
  { id: "ndx", cat: "INDICES", catAr: "", symbol: "USTEC", nameEn: "NASDAQ 100", nameAr: "", unit: "pts", currency: "USD", biquoteSymbol: "USTEC", instrumentType: "INDEX_CFD", instrumentTypeAr: "" },
  { id: "dji", cat: "INDICES", catAr: "", symbol: "US30", nameEn: "Dow Jones", nameAr: "", unit: "pts", currency: "USD", biquoteSymbol: "US30", instrumentType: "INDEX_CFD", instrumentTypeAr: "" },

  // 4. Major Currency Pairs
  { id: "eurusd", cat: "FX", catAr: "", symbol: "EUR/USD", nameEn: "EUR / USD", nameAr: "", unit: "", currency: "USD", biquoteSymbol: "EURUSD", instrumentType: "FOREX", instrumentTypeAr: "" },
  { id: "gbpusd", cat: "FX", catAr: "", symbol: "GBP/USD", nameEn: "GBP / USD", nameAr: "", unit: "", currency: "USD", biquoteSymbol: "GBPUSD", instrumentType: "FOREX", instrumentTypeAr: "" },
  { id: "usdchf", cat: "FX", catAr: "", symbol: "USD/CHF", nameEn: "USD / CHF", nameAr: "", unit: "", currency: "CHF", biquoteSymbol: "USDCHF", instrumentType: "FOREX", instrumentTypeAr: "" },
];

let marketCache: {
  lastFetched: number;
  backoffUntil: number;
  payload: any;
} = {
  lastFetched: 0,
  backoffUntil: 0,
  payload: null,
};
const CACHE_TTL_MS = 60 * 1000;
const BACKOFF_MS = 90 * 1000;

function formatInstrumentPrice(val: number | null | undefined, cat: string): string | null {
  if (val === null || val === undefined || isNaN(val)) return null;
  if (cat === "FX") return val.toFixed(4);
  if (val >= 1000) return val.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return val.toFixed(2);
}

function isGlobalForexMarketOpen(): boolean {
  const d = new Date();
  const day = d.getUTCDay();
  const hr = d.getUTCHours();
  if (day === 6) return false;
  if (day === 5 && hr >= 21) return false;
  if (day === 0 && hr < 21) return false;
  return true;
}

app.get("/api/market-ticker", async (req: Request, res: Response) => {
  const twelveDataKey =
    process.env["TWELVE_DATA_API_KEY"] || process.env["MARKET_DATA_API_KEY"] || "";
  const now = Date.now();

  if (now < marketCache.backoffUntil) {
    if (marketCache.payload) {
      return res.json({
        ...marketCache.payload,
        cached: true,
        status: "DELAYED",
        backoffActive: true,
      });
    }
    return res.json({
      status: "UNAVAILABLE",
      configured: Boolean(twelveDataKey),
      provider: twelveDataKey ? "Twelve Data + Biquote" : "Biquote",
      lastUpdated: null,
      cooldownSeconds: Math.ceil((marketCache.backoffUntil - now) / 1000),
      message: "Upstream rate limit cooldown active. Next live refresh queued.",
      instruments: REQUIRED_INSTRUMENTS.map((inst) => ({
        ...inst,
        price: null,
        formattedPrice: null,
        status: "UNAVAILABLE",
        lastUpdated: null,
      })),
    });
  }

  if (marketCache.payload && now - marketCache.lastFetched < CACHE_TTL_MS) {
    return res.json({ ...marketCache.payload, cached: true });
  }

  try {
    let twelveDataMap: Record<string, any> = {};

    if (twelveDataKey) {
      try {
        const supportedSymbols = "XAU/USD,EUR/USD,GBP/USD,USD/CHF";
        const apiUrl = `https://api.twelvedata.com/price?symbol=${encodeURIComponent(supportedSymbols)}&apikey=${encodeURIComponent(twelveDataKey)}`;

        const response = await fetch(apiUrl, {
          headers: { Accept: "application/json" },
          signal: AbortSignal.timeout(6000),
        });

        if (response.status === 429) {
          marketCache.backoffUntil = now + BACKOFF_MS;
        } else if (response.ok) {
          const json = (await response.json()) as any;
          if (json.code === 429 || (json.status === "error" && typeof json.message === "string" && json.message.includes("credits"))) {
            marketCache.backoffUntil = now + BACKOFF_MS;
          } else {
            twelveDataMap = json;
          }
        }
      } catch {
        // Silently continue to fallback provider
      }
    }

    const missingInstruments = REQUIRED_INSTRUMENTS.filter((inst) => {
      const q = twelveDataMap[inst.symbol] || twelveDataMap[inst.symbol.replace("/", "")];
      return !q || !q.price || q.code;
    });

    let biquoteMap: Record<string, any> = {};
    if (missingInstruments.length > 0) {
      try {
        const queryParams = missingInstruments.map((m) => `symbols=${encodeURIComponent(m.biquoteSymbol)}`).join("&");
        const biquoteUrl = `https://biquote.io/api/latest?${queryParams}`;

        const bqRes = await fetch(biquoteUrl, {
          headers: { Accept: "application/json" },
          signal: AbortSignal.timeout(6000),
        });

        if (bqRes.ok) {
          biquoteMap = (await bqRes.json()) as any;
        }
      } catch {
        // Silently continue
      }
    }

    const forexOpen = isGlobalForexMarketOpen();
    let liveCount = 0;
    let staleCount = 0;

    const mergedInstruments = REQUIRED_INSTRUMENTS.map((inst) => {
      const tdQuote = twelveDataMap[inst.symbol] || twelveDataMap[inst.symbol.replace("/", "")];
      if (tdQuote && tdQuote.price && !tdQuote.code) {
        const rawPrice = parseFloat(tdQuote.price);
        if (!isNaN(rawPrice) && rawPrice > 0) {
          const isLive = forexOpen;
          if (isLive) liveCount++;
          else staleCount++;
          return {
            ...inst,
            source: "Twelve Data",
            providerSymbol: inst.symbol,
            price: rawPrice,
            formattedPrice: formatInstrumentPrice(rawPrice, inst.cat),
            status: isLive ? "LIVE" : "DELAYED",
            marketState: isLive ? "open" : "closed",
            isLive,
            lastUpdated: new Date().toISOString(),
          };
        }
      }

      const bqQuote = biquoteMap[inst.biquoteSymbol];
      if (bqQuote) {
        let rawPrice: number | null = null;
        if (typeof bqQuote.mid === "number" && bqQuote.mid > 0) {
          rawPrice = bqQuote.mid;
        } else if (typeof bqQuote.bid === "number" && typeof bqQuote.ask === "number" && bqQuote.bid > 0 && bqQuote.ask > 0) {
          rawPrice = (bqQuote.bid + bqQuote.ask) / 2;
        } else if (typeof bqQuote.bid === "number" && bqQuote.bid > 0) {
          rawPrice = bqQuote.bid;
        } else if (typeof bqQuote.last === "number" && bqQuote.last > 0) {
          rawPrice = bqQuote.last;
        }

        if (rawPrice !== null && !isNaN(rawPrice) && rawPrice > 0) {
          const isMarketOpen = bqQuote.marketState === "open" && !bqQuote.stale;
          const quoteStatus = isMarketOpen ? "LIVE" : bqQuote.stale || bqQuote.marketState === "closed" ? "STALE" : "DELAYED";

          if (isMarketOpen) liveCount++;
          else staleCount++;

          return {
            ...inst,
            source: "Biquote",
            providerSymbol: bqQuote.symbol || inst.biquoteSymbol,
            price: rawPrice,
            formattedPrice: formatInstrumentPrice(rawPrice, inst.cat),
            status: quoteStatus,
            marketState: bqQuote.marketState || (isMarketOpen ? "open" : "closed"),
            isLive: isMarketOpen,
            quoteAgeSeconds: bqQuote.quoteAgeSeconds || null,
            lastUpdated: bqQuote.timestamp || bqQuote.lastQuoteAt || null,
          };
        }
      }

      return {
        ...inst,
        source: null,
        providerSymbol: null,
        price: null,
        formattedPrice: null,
        status: "UNAVAILABLE",
        marketState: "unavailable",
        isLive: false,
        lastUpdated: null,
      };
    });

    const hasAnyQuotes = mergedInstruments.some((i) => i.price !== null);
    const overallStatus = liveCount > 0 ? "LIVE" : staleCount > 0 ? "DELAYED" : "UNAVAILABLE";

    const payload = {
      status: overallStatus,
      configured: true,
      provider: "Twelve Data (Primary) + Biquote (Supplementary)",
      lastUpdated: new Date().toISOString(),
      instruments: mergedInstruments,
      summary: {
        total: REQUIRED_INSTRUMENTS.length,
        twelveDataCount: mergedInstruments.filter((i) => i.source === "Twelve Data").length,
        biquoteCount: mergedInstruments.filter((i) => i.source === "Biquote").length,
        unavailableCount: mergedInstruments.filter((i) => i.status === "UNAVAILABLE").length,
      },
    };

    if (hasAnyQuotes) {
      marketCache = {
        lastFetched: now,
        backoffUntil: marketCache.backoffUntil,
        payload,
      };
      return res.json(payload);
    }

    if (marketCache.payload) {
      return res.json({
        ...marketCache.payload,
        cached: true,
        status: "DELAYED",
      });
    }

    return res.json(payload);
  } catch (err: any) {
    if (marketCache.payload) {
      return res.json({
        ...marketCache.payload,
        cached: true,
        status: "DELAYED",
      });
    }
    return res.json({
      status: "UNAVAILABLE",
      configured: true,
      provider: "Twelve Data + Biquote",
      lastUpdated: null,
      error: err.message,
      instruments: REQUIRED_INSTRUMENTS.map((inst) => ({
        ...inst,
        price: null,
        formattedPrice: null,
        status: "UNAVAILABLE",
        lastUpdated: null,
      })),
    });
  }
});

app.use((req: Request, res: Response) => {
  res.setHeader("Cache-Control", "no-cache, must-revalidate");
  res.sendFile(path.join(__dirname, "index.html"));
});

const server = app.listen(port, host, () => {
  console.log(`Server is running on port ${port} (host ${host})`);
});

server.on("error", (err: any) => {
  console.error(`Server error on port ${port}:`, err);
  process.exit(1);
});

process.on("SIGTERM", () => {
  server.close(() => {
    process.exit(0);
  });
});

process.on("SIGINT", () => {
  server.close(() => {
    process.exit(0);
  });
});
